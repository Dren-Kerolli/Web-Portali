# Online-news-portal-using-PHP

Online News Portal is a fully dynamic web-application using PHP as a backed that allows user to upload the current news and arrange them based on different categories.
